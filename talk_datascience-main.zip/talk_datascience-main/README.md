# talk_datascience

O objetivo deste repositório é armazenar os slides da apresentação "Da Estatística para Ciência de Dados" para a Jornada Científica de Probabilidade e Estatística da UFPE.

Roteiro

 ### 1 - Apresentar a profissão e mostrar sua ascensão 

  Principais skills, ramificações de um cientista de dados

 ### 2 - Abordar meu dia-a-dia na profissão

 Mostrar alguns cases, correlacionando com disciplinas da graduação e/ou com disciplinas de outras áreas que são legais como opção para quem precisa ou está disposto a cursar algo fora do departamento

### 3 - Fechar falando sobre o que esperar numa entrevista e de um time de data science

 Dinâmica de uma entrevista

 mudança no curriculo de liderança de um time de data science

 Academia X mercado de trabalho
